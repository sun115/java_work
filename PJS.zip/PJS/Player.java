import java.util.Random;
import java.util.Scanner;

public class Player {

	String name = "";
	int hp = 0;
	int playerProperty = 0; // 불 = 0, 물 = 1, 풀 = 2, 불<물<풀<불	
	int playerHitRate = 0;  // 공격력
	
	Scanner scanner = new Scanner(System.in);
	Random random = new Random();
	
	Player () {
	// hp는 150으로 고정, 이름&속성은 input값(메인에서), 공격력은 10~20사이  랜덤값
		this.hp = 150;
//		this.name = scanner.nextLine();
//		this.playerProperty = scanner.nextInt();
		this.playerHitRate = random.nextInt(21)+10;
	}
	
	// player 남은 체력 확인
	public boolean status() {
		if (hp >= 0) {
			return true;
		}
		// ★★★★★★★★★ 추가 속성 ★★★★★★★★★
		// hp가 음수가 될 때 좀비로 변신, 공격에 맞으면 자신의 공격력 증폭
		else if (hp == 0) {
			System.out.println("\n※ SYSTEM WARNING ※\n주의하세요! 플레이어 " + this.name + "이 좀비가 되었습니다.\n좀비를 공격한다면 무서운 일이 일어납니다." + this.name + " : 으어어ㅓ어,,,\n");
			this.name = "좀비" + this.name;
			
			return true;
		}
		return true;
	
	}
	// player가 공격받을 때 (속성값에 따라)
	public void beUnderAttack(int enemyHitRate, int enemyProperty) {
		Random random = new Random();
		int hitNumber = random.nextInt(10);
		
		// 좀비가 되었을 때에는 무조건 공격에 맞게 함. (좀비 변신 경고문이 중복으로 뜨지 않게 하기 위함)
		if(hp==0) {
			if (hitNumber < 11) {
				System.out.println("좀비가 공격받았습니다. 좀비의 공격력이 상습합니다.");
				hp = hp - enemyHitRate;
				playerHitRate = 9999999;
			}
		}
		
		// enemy가 player에게 공격을 성공한 경우 
		// enemyHitRate = 적의 공격력, enemyProperty = 적의 속성
		if (hitNumber <= 3) {
			if (playerProperty == 0 && enemyProperty == 1) {
				hp = hp - (enemyHitRate+5);
				System.out.println(this.name + "이(가)" + (enemyHitRate + 5) + "의 피해를 입었습니다.");
			} else if (playerProperty == 0 && enemyProperty == 2) {
				hp = hp - (enemyHitRate-2);
				System.out.println(this.name + "이(가)" + (enemyHitRate - 2) + "의 피해를 입었습니다.");
			}else if (playerProperty == 1 && enemyProperty == 0) {
				hp = hp - (enemyHitRate-2);
				System.out.println(this.name + "이(가)" + (enemyHitRate - 2) + "의 피해를 입었습니다.");
			} else if (playerProperty == 1 && enemyProperty == 2) {
				hp = hp - (enemyHitRate+5);
				System.out.println(this.name + "이(가)" + (enemyHitRate + 5) + "의 피해를 입었습니다.");
			} else if (playerProperty == 2 && enemyProperty == 1) {
				hp = hp - (enemyHitRate-2);
				System.out.println(this.name + "이(가)" + (enemyHitRate - 2) + "의 피해를 입었습니다.");
			} else if (playerProperty == 2 && enemyProperty == 0) {
				hp = hp - (enemyHitRate+5);
				System.out.println(this.name + "이(가)" + (enemyHitRate + 5) + "의 피해를 입었습니다.");
			} else {
				hp = hp - enemyHitRate;
				System.out.println(this.name + "이(가)" + enemyHitRate + "의 피해를 입었습니다.");
			}
		// player가 공격을 회피할 경우	
		} else {
		System.out.println(this.name + "이(가) 공격을 회피했습니다.");
	}
	}
}
