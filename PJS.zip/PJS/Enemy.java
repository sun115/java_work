import java.util.Random;

public class Enemy {
	
	String name = "";
	int hp = 0;
	int enemyProperty = 0;
	int enemyHitRate = 0;  // 공격력
	String[] namearr = {"JS","JW","SC","BK","SY"};
	
	// enemyProperty : fire = 0, water = 1, grass = 2
	// fire > water , water > grass , grass > fire
		
	Random random = new Random();
		
	Enemy() {
		int a = random.nextInt(5);
		this.name = namearr[a];
		this.hp = random.nextInt(101)+80;
		this.enemyProperty = random.nextInt(2);
		this.enemyHitRate = random.nextInt(21)+10;
		
	}
	// enemy의 상태 확인
	public boolean status() {
		if (hp > 0) {
			return true;
		} 
		return false;
			
	}
	public void beUnderAttack(int playerProperty, int playerHitRate) {
		Random random = new Random();
		int hitNumber = random.nextInt(10);
		//  player가 enemy에게 공격을 성공한 경우 
		//  playerHitRate = 플레이어의 공격력, playerProperty = 플레이어의 속성
		if (hitNumber <= 3) {
			if (enemyProperty == 0 && playerProperty == 1) {
				hp = hp - (playerHitRate+5);
				System.out.println(this.name + "이(가)" + (playerHitRate + 5) + "의 피해를 입었습니다.");
			} else if (enemyProperty == 0 && playerProperty == 2) {
				hp = hp - (playerHitRate-2);
				System.out.println(this.name + "이(가)" + (playerHitRate - 2) + "의 피해를 입었습니다.");
			}else if (enemyProperty == 1 && playerProperty == 0) {
				hp = hp - (playerHitRate-2);
				System.out.println(this.name + "이(가)" + (playerHitRate - 2) + "의 피해를 입었습니다.");
			} else if (enemyProperty == 1 && playerProperty == 2) {
				hp = hp - (playerHitRate+5);
				System.out.println(this.name + "이(가)" + (playerHitRate + 5) + "의 피해를 입었습니다.");
			} else if (enemyProperty == 2 && playerProperty == 1) {
				hp = hp - (playerHitRate-2);
				System.out.println(this.name + "이(가)" + (playerHitRate - 2) + "의 피해를 입었습니다.");
			} else if (enemyProperty == 2 && playerProperty == 0) {
				hp = hp - (playerHitRate+5);
				System.out.println(this.name + "이(가)" + (playerHitRate + 5) + "의 피해를 입었습니다.");
			} else {
				hp = hp - playerHitRate;
				System.out.println(this.name + "이(가)" + playerHitRate + "의 피해를 입었습니다.");
			}
		// player가 공격을 회피할 경우	
		} 
		else if (hitNumber == 2) {
			System.out.println("플레이어가 " + this.name + "에게 마법을 걸었습니다.\n" + this.name + "의 속성이  변합니다.");
			enemyProperty = random.nextInt(2);
		}
		else {
		System.out.println(this.name + "이(가) 공격을 회피했습니다.");
	}
	}

}